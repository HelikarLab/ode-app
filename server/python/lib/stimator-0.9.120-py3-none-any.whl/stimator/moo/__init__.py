"""S-timator package, multi-objective optimization module"""

